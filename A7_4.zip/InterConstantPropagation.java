/*
 * Tai-e: A Static Analysis Framework for Java
 *
 * Copyright (C) 2022 Tian Tan <tiantan@nju.edu.cn>
 * Copyright (C) 2022 Yue Li <yueli@nju.edu.cn>
 *
 * This file is part of Tai-e.
 *
 * Tai-e is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation, either version 3
 * of the License, or (at your option) any later version.
 *
 * Tai-e is distributed in the hope that it will be useful,but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General
 * Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with Tai-e. If not, see <https://www.gnu.org/licenses/>.
 */

package pascal.taie.analysis.dataflow.inter;

import pascal.taie.World;
import pascal.taie.analysis.dataflow.analysis.constprop.CPFact;
import pascal.taie.analysis.dataflow.analysis.constprop.ConstantPropagation;
import pascal.taie.analysis.dataflow.analysis.constprop.Value;
import pascal.taie.analysis.graph.cfg.CFG;
import pascal.taie.analysis.graph.cfg.CFGBuilder;
import pascal.taie.analysis.graph.icfg.CallEdge;
import pascal.taie.analysis.graph.icfg.CallToReturnEdge;
import pascal.taie.analysis.graph.icfg.NormalEdge;
import pascal.taie.analysis.graph.icfg.ReturnEdge;
import pascal.taie.analysis.pta.PointerAnalysisResult;
import pascal.taie.config.AnalysisConfig;
import pascal.taie.ir.IR;
import pascal.taie.ir.exp.*;
import pascal.taie.ir.stmt.*;
import pascal.taie.language.classes.JField;
import pascal.taie.language.classes.JMethod;
import soot.jimple.FieldRef;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Implementation of interprocedural constant propagation for int values.
 */
public class InterConstantPropagation extends
        AbstractInterDataflowAnalysis<JMethod, Stmt, CPFact> {

    public static final String ID = "inter-constprop";

    private final ConstantPropagation cp;

    private PointerAnalysisResult pta;



    public InterConstantPropagation(AnalysisConfig config) {
        super(config);
        cp = new ConstantPropagation(new AnalysisConfig(ConstantPropagation.ID));
    }

    @Override
    protected void initialize() {
        String ptaId = getOptions().getString("pta");
        PointerAnalysisResult pta = World.get().getResult(ptaId);
        // You can do initialization work here
        this.pta = pta;
    }

    @Override
    public boolean isForward() {
        return cp.isForward();
    }

    @Override
    public CPFact newBoundaryFact(Stmt boundary) {
        IR ir = icfg.getContainingMethodOf(boundary).getIR();
        return cp.newBoundaryFact(ir.getResult(CFGBuilder.ID));
    }

    @Override
    public CPFact newInitialFact() {
        return cp.newInitialFact();
    }

    @Override
    public void meetInto(CPFact fact, CPFact target) {
        cp.meetInto(fact, target);
    }

    @Override
    protected boolean transferCallNode(Stmt stmt, CPFact in, CPFact out) {
        // TODO - finish me
        CPFact newOut = in.copy();
        if(!newOut.equals(out)) {
            out.copyFrom(newOut);
            return true;
        }
        return false;
    }

    @Override
    protected boolean transferNonCallNode(Stmt stmt, CPFact in, CPFact out) {
        // TODO - finish me
        return transferNode(stmt, in, out);
    }

    @Override
    protected CPFact transferNormalEdge(NormalEdge<Stmt> edge, CPFact out) {
        // TODO - finish me
        CPFact res = out.copy();
        return res;
    }

    @Override
    protected CPFact transferCallToReturnEdge(CallToReturnEdge<Stmt> edge, CPFact out) {
        // TODO - finish me
        CPFact res = out.copy();
        Invoke callSite = (Invoke) edge.getSource();
        Var resultVar = callSite.getResult();
        if(resultVar != null && ConstantPropagation.canHoldInt(resultVar)) {
            // kill the result variable
            res.remove(resultVar);
        }

        return res;
    }

    @Override
    protected CPFact transferCallEdge(CallEdge<Stmt> edge, CPFact callSiteOut) {
        // TODO - finish me
        //        JMethod callee = (JMethod) edge.getTarget();
        JMethod callee = edge.getCallee();
        IR calleeIR = callee.getIR();
        List<Var> formals = calleeIR.getParams();
        int cnt_formals = formals.size();

        CPFact boundary = cp.newInitialFact();

        Invoke callSite = (Invoke) edge.getSource();
        // List<Var> uses = callSite.getInvokeExp().getUses();
        // the line above cause bug (failed;pass testcase 1013/1065)
        // why getArgs() is fine though?
        List<Var> uses = callSite.getInvokeExp().getArgs();
        int cnt_args = uses.size();

        int k = Math.min(cnt_args, cnt_formals);
        for(int i = 0; i < k; i++) {
            Exp actualExp = uses.get(i);
            Value v = evaluate(actualExp,callSiteOut);
            Var formal = formals.get(i);
            if(ConstantPropagation.canHoldInt(formal)) {
                boundary.update(formal, v);
            }
        }
        return boundary;
    }

    @Override
    protected CPFact transferReturnEdge(ReturnEdge<Stmt> edge, CPFact returnOut) {
        // TODO - finish me
        CPFact ret = cp.newInitialFact();

        Collection<Var> returnVars = edge.getReturnVars();
        Value merged = Value.getUndef();
        for(Var r: returnVars) {
            Value v = returnOut.get(r);
            if(merged.isUndef()){
                merged = v;
            }
            else {
                merged = cp.meetValue(merged, v);
            }
        }
        if(merged.isUndef()) {
            return ret;
        }

        Invoke callSite = (Invoke) edge.getCallSite();
        Var resultVar = callSite.getResult();
        if(resultVar != null && ConstantPropagation.canHoldInt(resultVar)) {
            ret.update(resultVar, merged);
        }

        return ret;
    }

    public boolean transferNode(Stmt stmt, CPFact in, CPFact out) {
        CPFact newOut = in.copy();

        if(stmt instanceof DefinitionStmt<?,?> defstmt){
            LValue lvalue = defstmt.getLValue();
            RValue rvalue = defstmt.getRValue();

            // when "x=m(...)" or "x=o.f" , i.e. right side is not a "exp" we wanted now
            // evaluate() returns NAC then
            Value rvalue_evaluated = evaluate(rvalue,in);

            if(lvalue instanceof Var var && ConstantPropagation.canHoldInt(var)){
                newOut.update(var, rvalue_evaluated);
            }
            // for lvalue like "o.f = ..." nothing should be done
            // just the identity map from IN -> OUT
            // which has been done in the first line
        }
        if(!newOut.equals(out)){
            out.copyFrom(newOut);
            return true;
        }
        return false;
    }

    public Value evaluate(Exp exp, CPFact in) {
        if(exp instanceof InstanceFieldAccess x_f) {
            return Value.getNAC();
        } else if (exp instanceof  StaticFieldAccess T_f) {
            Value res = Value.getUndef();
            boolean flag = false;
            for(Stmt stmt : icfg.getNodes()){
                if(stmt instanceof StoreField storeField &&
                        storeField.getFieldAccess().getFieldRef().resolve().equals(T_f.getFieldRef().resolve())){
                    flag = true;
                    Value rhs_evaluated = evaluate(storeField.getRValue(),in);
                    res = cp.meetValue(res,rhs_evaluated);
                }
            }
            if(flag){
                return res;
            }
            return Value.getNAC();
        } else if(exp instanceof ArrayAccess a_i){
            return Value.getNAC();
        }

        return ConstantPropagation.evaluate(exp, in);
    }

}
